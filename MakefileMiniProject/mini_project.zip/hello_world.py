# hello_world.py
with open("output1.txt", "w") as f:
    f.write("This is the output of script 1.\n")
    f.write("Line 2\n")
    f.write("Line 3\n")
    f.write("Line 4\n")
    f.write("Line 5\n")

