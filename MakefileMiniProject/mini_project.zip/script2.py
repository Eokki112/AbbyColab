# script2.py
with open("output2.txt", "w") as f:
    f.write("This is script 2.\n")
    f.write("We love JC./n")
    f.write("I need another break though.\n")
    f.write("Almost done with this semester\n")
    f.write("Finally!\n")

